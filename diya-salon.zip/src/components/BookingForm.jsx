export default function BookingForm() {
  const handleSubmit = (e) => {
    e.preventDefault();
    const name = e.target.name.value;
    const phone = e.target.phone.value;
    const service = e.target.service.value;
    const date = e.target.date.value;
    const message = `Hello, I’d like to book an appointment.
Name: ${name}
Phone: ${phone}
Service: ${service}
Date: ${date}`;
    window.open(`https://wa.me/447717646965?text=${encodeURIComponent(message)}`, "_blank");
    alert("Your appointment request has been sent!");
  };
  return (
    <section className="py-16 px-6 bg-white text-center" id="booking">
      <h2 className="text-4xl font-bold text-pink-600 mb-6">Book Appointment</h2>
      <form onSubmit={handleSubmit} className="max-w-xl mx-auto grid gap-4 text-left">
        <input type="text" name="name" placeholder="Your Name" required className="p-3 border rounded" />
        <input type="tel" name="phone" placeholder="Phone Number" required className="p-3 border rounded" />
        <input type="text" name="service" placeholder="Service" required className="p-3 border rounded" />
        <input type="date" name="date" required className="p-3 border rounded" />
        <button className="bg-pink-600 hover:bg-pink-700 text-white py-3 rounded-lg">Confirm Booking</button>
      </form>
    </section>
  );
}