export default function About() {
  return (
    <section className="py-16 px-6 bg-white text-center" id="about">
      <h2 className="text-4xl font-bold text-pink-600 mb-6">About Us</h2>
      <p className="max-w-3xl mx-auto text-gray-600 text-lg">
        At Diya Hair & Beauty Salon, we believe every woman deserves to feel beautiful. 
        From stylish haircuts to relaxing facials, we provide a wide range of services designed 
        to bring out your inner glow. Visit us at 21 New Hall Lane, Preston PR1 5NU.
      </p>
    </section>
  );
}