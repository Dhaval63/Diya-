export default function Hero() {
  return (
    <section className="relative h-screen flex items-center justify-center text-center text-white">
      <video autoPlay loop muted playsInline className="absolute inset-0 w-full h-full object-cover -z-10">
        <source src="https://cdn.pixabay.com/vimeo/649377282/beauty-salon-2-10419.mp4?width=1920&hash=1a5c9b" type="video/mp4" />
      </video>
      <div className="bg-black bg-opacity-50 p-6 rounded-xl">
        <h1 className="text-5xl md:text-7xl font-bold">Diya Hair & Beauty Salon</h1>
        <p className="mt-4 text-xl">Where Elegance Begins</p>
        <a href="#booking" className="mt-6 inline-block px-6 py-3 bg-pink-600 hover:bg-pink-700 rounded-full text-white text-lg">
          Book Appointment
        </a>
      </div>
    </section>
  );
}