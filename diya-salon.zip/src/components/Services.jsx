import { FaCut, FaPaintBrush, FaSpa, FaRing } from "react-icons/fa";
const services = [
  { icon: <FaCut />, title: "Haircuts & Styling" },
  { icon: <FaPaintBrush />, title: "Hair Coloring" },
  { icon: <FaSpa />, title: "Facials & Waxing" },
  { icon: <FaRing />, title: "Bridal Makeup" },
];
export default function Services() {
  return (
    <section className="py-16 bg-gray-50 text-center" id="services">
      <h2 className="text-4xl font-bold text-pink-600 mb-10">Our Services</h2>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 px-6">
        {services.map((s, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl shadow hover:shadow-lg transition">
            <div className="text-pink-600 text-5xl mb-4">{s.icon}</div>
            <h3 className="text-xl font-semibold">{s.title}</h3>
          </div>
        ))}
      </div>
    </section>
  );
}