export default function Contact() {
  return (
    <section className="py-16 bg-gray-50 text-center" id="contact">
      <h2 className="text-4xl font-bold text-pink-600 mb-6">Contact Us</h2>
      <p className="text-lg">📍 21 New Hall Lane, Preston PR1 5NU</p>
      <p className="text-lg">📞 07717646965</p>
      <p className="text-lg">📧 rana2001dhaval@gmail.com</p>
      <div className="mt-6">
        <iframe title="map" src="https://www.google.com/maps?q=21%20New%20hall%20lane%20Preston%20PR15NU&output=embed"
          className="w-full h-64 rounded-xl shadow" allowFullScreen></iframe>
      </div>
    </section>
  );
}