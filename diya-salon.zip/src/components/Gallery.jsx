import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const images = [
  "/images/client1.jpg",
  "/images/client2.jpg",
  "/images/client3.jpg",
  "/images/client4.jpg",
];
export default function Gallery() {
  const settings = { dots: true, infinite: true, autoplay: true, slidesToShow: 1, slidesToScroll: 1 };
  return (
    <section className="py-16 bg-white text-center" id="gallery">
      <h2 className="text-4xl font-bold text-pink-600 mb-10">Gallery</h2>
      <div className="max-w-3xl mx-auto">
        <Slider {...settings}>
          {images.map((img, i) => (
            <div key={i}><img src={img} alt="Client work" className="rounded-xl shadow-lg mx-auto" /></div>
          ))}
        </Slider>
      </div>
    </section>
  );
}