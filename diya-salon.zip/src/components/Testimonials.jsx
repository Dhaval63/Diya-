export default function Testimonials() {
  const reviews = [
    { name: "Sophia", text: "Amazing service! I felt like a queen." },
    { name: "Aisha", text: "The bridal makeup was perfect. Thank you!" },
  ];
  return (
    <section className="py-16 bg-gray-50 text-center" id="testimonials">
      <h2 className="text-4xl font-bold text-pink-600 mb-10">What Our Clients Say</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 px-6 max-w-4xl mx-auto">
        {reviews.map((r, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl shadow hover:shadow-lg">
            <p className="italic text-gray-600">“{r.text}”</p>
            <h4 className="mt-4 font-semibold">{r.name}</h4>
          </div>
        ))}
      </div>
    </section>
  );
}